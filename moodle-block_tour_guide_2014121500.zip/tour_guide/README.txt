moodle-block_tour_guide
=====================

Moodle Block - tour_guide
Developed by - Thomas Threadgold - LearningWorks Ltd

This block plugin allows you to add a customisable tutorial sequence on each page. By specifying the CSS selector, you can highlight a section of the page and write a short description about that element. Each instance of the block allows up to 20 tutorial tips.

VERSION UPDATES
===============

Version 2014111900,
Initial release
